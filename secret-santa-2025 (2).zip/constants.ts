export const SHARED_PASSWORD = "navidad2025";
export const ADMIN_PASSWORD = "gerito2025";
export const ADMIN_NAME = "Gerardo";
export const STORAGE_KEY = "secret_santa_v1";
export const TARGET_PARTICIPANTS = 18;
